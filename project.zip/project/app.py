from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from forms import SignupForm, LoginForm
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['UPLOAD_FOLDER'] = 'static/profile_pics'

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(150))
    last_name = db.Column(db.String(150))
    profile_pic = db.Column(db.String(150))
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    address_line1 = db.Column(db.String(150))
    city = db.Column(db.String(150))
    state = db.Column(db.String(150))
    pincode = db.Column(db.String(150))
    user_type = db.Column(db.String(50))

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = SignupForm()
    if form.validate_on_submit():
        if form.password.data != form.confirm_password.data:
            flash('Passwords do not match!', 'danger')
            return redirect(url_for('signup'))

        # Check if email or username already exists
        existing_user = User.query.filter((User.email == form.email.data) | (User.username == form.username.data)).first()
        if existing_user:
            if existing_user.email == form.email.data:
                flash('Email already exists. Please choose a different email.', 'danger')
            else:
                flash('Username already exists. Please choose a different username.', 'danger')
            return redirect(url_for('signup'))

        hashed_password = generate_password_hash(form.password.data)
        profile_pic = form.profile_pic.data
        profile_pic_filename = os.path.join('static/profile_pics', profile_pic.filename)
        profile_pic.save(profile_pic_filename)

        # Store only the relative path to the profile picture

        new_user = User(
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            profile_pic=profile_pic_filename,
            username=form.username.data,
            email=form.email.data,
            password=hashed_password,
            address_line1=form.address_line1.data,
            city=form.city.data,
            state=form.state.data,
            pincode=form.pincode.data,
            user_type=form.user_type.data
        )

        db.session.add(new_user)
        db.session.commit()

        flash('Account created successfully!', 'success')
        return redirect(url_for('login'))

    return render_template('signup.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password, form.password.data):
            session['user_id'] = user.id
            session['user_type'] = user.user_type
            if user.user_type == 'Patient':
                return redirect(url_for('patient_dashboard'))
            elif user.user_type == 'Doctor':
                return redirect(url_for('doctor_dashboard'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')

    return render_template('login.html', form=form)

@app.route('/patient_dashboard')
def patient_dashboard():
    user = User.query.get(session['user_id'])
    return render_template('patient_dashboard.html', user=user)

@app.route('/doctor_dashboard')
def doctor_dashboard():
    user = User.query.get(session['user_id'])
    return render_template('doctor_dashboard.html', user=user)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
